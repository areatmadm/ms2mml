(function($) {
	$(document).ready(function() {
		$.slidebars();
	});
}) (jQuery);